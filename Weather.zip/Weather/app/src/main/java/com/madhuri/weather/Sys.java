package com.madhuri.weather;

/**
 * Created by reddve5 on 7/27/17.
 */

public class Sys {
    public int type = 0;
    public int id = 0;
    public long sunrise = 0;
    public long sunset = 0;
}
