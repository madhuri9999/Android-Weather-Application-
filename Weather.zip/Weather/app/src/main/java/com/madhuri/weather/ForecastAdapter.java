package com.madhuri.weather;

import android.app.Activity;
import android.databinding.DataBindingUtil;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;

import com.madhuri.weather.databinding.ForecastListItemBinding;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Created by reddve5 on 7/29/17.
 */

public class ForecastAdapter extends RecyclerView.Adapter<ForecastAdapter.ViewHolder> {
    private static final String TAG = "ForecastAdapter";
    private final String IMAGE_BASE_URL = "http://openweathermap.org/img/w/";
    private List<Forecast> forecasts = new ArrayList<>();
    private Activity mActivity;

    public ForecastAdapter(Activity activity, List<Forecast> forecasts) {
        this.forecasts = forecasts;
        mActivity = activity;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        ForecastListItemBinding dataBinding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.forecast_list_item, null, false);
        return new ViewHolder(dataBinding);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Forecast forecast = forecasts.get(position);
        holder.dataBinding.textViewTemp.setText(forecast.main.temp+(WeatherActivity.units == 0 ? " \u2109" :" \u2103"));
        holder.dataBinding.textViewWeather.setText(forecast.weather.get(0).description);
        holder.dataBinding.textViewHumidity.setText(forecast.main.humidity+" %");
        holder.dataBinding.textViewPressure.setText(forecast.main.pressure+" hpa");
        holder.dataBinding.textViewWind.setText(String.valueOf(forecast.wind.speed+(WeatherActivity.units == 0 ? " m/h" :" m/s")));
        SimpleDateFormat dateFormat = new SimpleDateFormat("E dd:MM:yyyy HH-mm ", Locale.getDefault());
        holder.dataBinding.textViewDate.setText(dateFormat.format(new Date(forecast.dt*1000)));
        String uri = IMAGE_BASE_URL+forecast.weather.get(0).icon+".png";
        Log.i(TAG, "onPostExecute: IMAGE_BASE_URL :"+uri);
        Picasso.with(mActivity).load(Uri.parse(uri)).into(holder.dataBinding.imageViewIcon);
    }

    @Override
    public int getItemCount() {
        return forecasts.size();
    }

    public void setList(List<Forecast> today) {
        forecasts = today;
        notifyDataSetChanged();
    }

    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder
    public static class ViewHolder extends RecyclerView.ViewHolder {
        // each data item is just a string in this case
        public ForecastListItemBinding dataBinding;

        public ViewHolder(ForecastListItemBinding dataBinding) {
            super(dataBinding.getRoot());
            this.dataBinding = dataBinding;
        }
    }

}
