package com.madhuri.weather;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by reddve5 on 7/27/17.
 */

public class WeatherForecastResponse {
    public City city;
    public List<Forecast> list = new ArrayList<>();
    public int cod = 0;
    public String message = "";
    public int cnt = 0;
}
