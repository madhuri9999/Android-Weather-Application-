package com.madhuri.weather;

/**
 * Created by reddve5 on 7/14/17.
 */

public class Coord {
    public double lat = 0;
    public double lon = 0;
}
