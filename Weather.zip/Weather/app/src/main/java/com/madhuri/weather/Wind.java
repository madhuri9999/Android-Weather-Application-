package com.madhuri.weather;

/**
 * Created by reddve5 on 7/14/17.
 */

public class Wind {
    public float speed = 0;
    public float deg = 0;
}
