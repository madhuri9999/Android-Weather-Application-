package com.madhuri.weather;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by reddve5 on 7/14/17.
 */

public class Forecast {
    public long dt = 0;
    public String dt_txt = "";
    public Wind wind;
    public Main main;
    public List<Weather> weather = new ArrayList<>();
}
