package com.madhuri.weather.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by reddve5 on 7/30/17.
 */

public class DBAdapter {

    // Database fields
    public static final String KEY_STATION_ID = "id";
    public static final String KEY_NAME = "name";
    public static final String DATABASE_TABLE_CITIES = "favoriteCities";

    private Context context;
    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;

    public DBAdapter(Context context) {
        this.context = context;
    }

    public DBAdapter open() throws SQLException {
        dbHelper = new DatabaseHelper(context);
        database = dbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        dbHelper.close();
    }

    /**
     *
     * @param favoriteCity
     */
    public int addFavoriteStation(String favoriteCity){
        int count = 0;
        ContentValues values = new ContentValues();
        values.put(KEY_NAME, favoriteCity);
        count = (int) database.insert(DATABASE_TABLE_CITIES, null, values);
        return count;
    }

    /**
     *
     * @return list of favorite stations
     */
    public List<String> getFavoriteCities() {
        Cursor cursor = null;
        List<String> favoriteCities = new ArrayList<String>();
        cursor = database.query(DATABASE_TABLE_CITIES, new String[] {KEY_NAME }, null,
                null, null, null, null);
        if (cursor != null) {
            if (cursor.getCount() > 0) {
                while (cursor.moveToNext()) {
                    String cityName = cursor.getString(0);
                    favoriteCities.add(cityName);
                }
            }
            cursor.close();
        }
        return favoriteCities;
    }

    /**
     *
     * @param cityName
     * @return String favorite city
     */
    public String getFavoriteCity(String cityName){
        String favoriteCityName = null;
        Cursor cursor = null;
        cursor = database.query(DATABASE_TABLE_CITIES, new String[]{KEY_NAME}, KEY_NAME+"=?", new String[]{String.valueOf(cityName)}, null, null, null);
        if (cursor != null) {
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                favoriteCityName= cursor.getString(0);
            }
            cursor.close();
        }
        return  favoriteCityName;
    }
    /**
     *
     * @param cityName
     * @return deletes the city name
     */
    public int deleteFavoriteCity(String cityName) {
        return database.delete(DATABASE_TABLE_CITIES, KEY_NAME + "=?",
                new String[] { cityName });
    }
}
