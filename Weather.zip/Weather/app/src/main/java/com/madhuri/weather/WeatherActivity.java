package com.madhuri.weather;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.support.v4.app.FragmentActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.madhuri.weather.database.DBAdapter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class WeatherActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private final int REQ_CODE_SPEECH_INPUT = 100;
    private Button sendButton;
    private AutoCompleteTextView searchTextView;
    private ImageView speakNow;
    private String postalCode = "";
    private Marker marker;
    public static DBAdapter dbAdapter;
    public static List<String> favoriteCities = new ArrayList<>();
    ArrayAdapter<String> adapter;
    private static final String TAG = "WeatherActivity";
    public static int units = 0; //Fahrenheit; 1 - Celsius

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        sendButton = findViewById(R.id.buttonSend);
        searchTextView = findViewById(R.id.editTextSearch);
        speakNow = findViewById(R.id.imageViewSpeak);

        searchTextView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(editable.toString().isEmpty()){
                    sendButton.setVisibility(View.GONE);
                    speakNow.setVisibility(View.VISIBLE);
                }else{
                    sendButton.setVisibility(View.VISIBLE);
                    speakNow.setVisibility(View.GONE);
                }
            }
        });

        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String searchKey = searchTextView.getText().toString().trim();
                if(!searchKey.isEmpty() && searchKey.length() == 5){
                    try {
                        Integer.parseInt(searchKey);
                        postalCode = searchKey;
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                    }
                }
                Intent intent = new Intent(getApplicationContext(), WeatherForecastActivity.class);

                if (!postalCode.isEmpty()) {
                    intent.putExtra("key", "zip");
                    intent.putExtra("searchKey", postalCode);
                    startActivity(intent);
                    postalCode = "";
                } else
                    if (!searchKey.isEmpty()) {
                    //intent.putExtra("key", "zip");
                    intent.putExtra("searchKey", searchKey);
                    startActivity(intent);
                    searchTextView.setText("");
                }else{
                    Toast.makeText(getApplicationContext(), "Enter city name", Toast.LENGTH_SHORT).show();
                }

            }
        });
        dbAdapter = new DBAdapter(getApplicationContext());

        dbAdapter.open();
        favoriteCities = dbAdapter.getFavoriteCities();
        dbAdapter.close();

        adapter = new ArrayAdapter<String>
                (this,android.R.layout.simple_list_item_1, favoriteCities);
        searchTextView.setAdapter(adapter);

    }

    public void speakNowClicked(View view) {
        promptSpeechInput();
    }

    @Override
    protected void onResume() {
        super.onResume();
        adapter = new ArrayAdapter<String>
                (this,android.R.layout.simple_list_item_1, favoriteCities);
        searchTextView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

    /**
     * Showing google speech input dialog
     * */
    private void promptSpeechInput() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT,"Say some city name");
        try {
            startActivityForResult(intent, REQ_CODE_SPEECH_INPUT);
        } catch (ActivityNotFoundException a) {
            Toast.makeText(getApplicationContext(),"Sorry! Your device doesn\\'t support speech input",
                    Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Receiving speech input
     * */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case REQ_CODE_SPEECH_INPUT: {
                if (resultCode == RESULT_OK && null != data) {

                    ArrayList<String> result = data
                            .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    //txtSpeechInput.setText(result.get(0));
                    searchTextView.setText(result.get(0));
                    searchTextView.setSelection(result.get(0).length());
                }
                break;
            }

        }
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        mMap.setOnMapLongClickListener(new GoogleMap.OnMapLongClickListener() {
            @Override
            public void onMapLongClick(LatLng latLng) {

                Log.i(TAG, "onMapLongClick: "+latLng.toString());
                Geocoder geocoder = new Geocoder(getApplicationContext(), Locale.getDefault());
                List<Address> addresses;
                try {
                    addresses = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1);
                    if (addresses != null && addresses.size() > 0) {
                        Address address = addresses.get(0);
                        String  city = address.getLocality();
                        //String addressLine = address.getAddressLine(0);
                        postalCode = address.getPostalCode();
                        searchTextView.setText(city);
                        searchTextView.setSelection(city.length());

                        if(marker == null){
                            marker = mMap.addMarker(new MarkerOptions().position(latLng).title(city+" "+postalCode));
                        }else{
                            marker.setPosition(latLng);
                            marker.setTitle(city+" "+postalCode);
                        }
                        marker.showInfoWindow();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

    }

}
