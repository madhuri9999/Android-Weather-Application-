package com.madhuri.weather;

/**
 * Created by reddve5 on 7/14/17.
 */

public class City {
    public String name = "";
    public String country = "";
    public Coord coord;
}
