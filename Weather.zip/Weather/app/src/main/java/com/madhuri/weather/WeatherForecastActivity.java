package com.madhuri.weather;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.net.Uri;
import android.os.AsyncTask;
import android.speech.RecognizerIntent;
import android.support.annotation.IdRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.madhuri.weather.databinding.ActivityWeatherForecastBinding;
import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class WeatherForecastActivity extends AppCompatActivity {
    private final int REQ_CODE_SPEECH_INPUT = 100;
    private static final String TAG = "WeatherForecastActivity";
    private String postalCode;
    private String city;
    private final String IMAGE_BASE_URL = "http://openweathermap.org/img/w/";
    private final String FORECAST_BASE_URL = "http://api.openweathermap.org/data/2.5/forecast?&APPID=c5847d937c149b421a19fb22856edd61";//&units=imperial";//units=imperial;metric
    private final String WEATHER_BASE_URL = "http://api.openweathermap.org/data/2.5/weather?&APPID=c5847d937c149b421a19fb22856edd61";//&units=imperial";//units=imperial;metric
    private ActivityWeatherForecastBinding dataBinding;
    private RecyclerView.LayoutManager mLayoutManager;
    private ForecastAdapter forecastAdapter;
    private List<Forecast> today = new ArrayList<>();
    private List<Forecast> tomorrow = new ArrayList<>();
    private List<Forecast> later = new ArrayList<>();
    private  ArrayAdapter adapter;
    private FirebaseAnalytics mFirebaseAnalytics;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        dataBinding = DataBindingUtil.setContentView(this, R.layout.activity_weather_forecast);
        String key = getIntent().getStringExtra("key");
        String searchKey = getIntent().getStringExtra("searchKey");
        dataBinding.forecastRecyclerView.setHasFixedSize(false);
        // use a linear layout manager
        mLayoutManager = new LinearLayoutManager(this);
        dataBinding.forecastRecyclerView.setLayoutManager(mLayoutManager);

        // Obtain the FirebaseAnalytics instance.
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);

        if(key != null && key.equals("zip")){
            new CurrentWeatherAsyncTask().execute("&zip="+searchKey);
            new WeatherForecastAsyncTask().execute("&zip="+searchKey);
        }else{
            new CurrentWeatherAsyncTask().execute("&q="+searchKey);
            new WeatherForecastAsyncTask().execute("&q="+searchKey);
        }

        dataBinding.editTextSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(editable.toString().isEmpty()){
                    dataBinding.buttonSend.setVisibility(View.GONE);
                    dataBinding.imageViewSpeak.setVisibility(View.VISIBLE);
                }else{
                    dataBinding.buttonSend.setVisibility(View.VISIBLE);
                    dataBinding.imageViewSpeak.setVisibility(View.GONE);
                }
            }
        });

        adapter = new ArrayAdapter<String>
                (this,android.R.layout.simple_list_item_1, WeatherActivity.favoriteCities);
        dataBinding.editTextSearch.setAdapter(adapter);
        dataBinding.toggleUnits.check(WeatherActivity.units == 0 ? R.id.fahrenheit : R.id.celsius);
        dataBinding.toggleUnits.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, @IdRes int i) {
                WeatherActivity.units = i == R.id.fahrenheit ? 0: 1;
                new CurrentWeatherAsyncTask().execute("&q="+city);
                new WeatherForecastAsyncTask().execute("&q="+city);
            }
        });
    }

    public void updateFavImage(String cityName){
        WeatherActivity.dbAdapter.open();
        if(WeatherActivity.dbAdapter.getFavoriteCity(cityName) != null){
            dataBinding.imageViewFavorite.setImageResource(android.R.drawable.star_big_on);
        }else{
            dataBinding.imageViewFavorite.setImageResource(android.R.drawable.star_big_off);
        }
        WeatherActivity.dbAdapter.close();
    }

    /**
     * Showing google speech input dialog
     * */
    private void promptSpeechInput() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT,"Say some city name");
        try {
            startActivityForResult(intent, REQ_CODE_SPEECH_INPUT);
        } catch (ActivityNotFoundException a) {
            Toast.makeText(getApplicationContext(),"Sorry! Your device doesn\\'t support speech input",
                    Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Receiving speech input
     * */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case REQ_CODE_SPEECH_INPUT: {
                if (resultCode == RESULT_OK && null != data) {

                    ArrayList<String> result = data
                            .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    //txtSpeechInput.setText(result.get(0));
                    dataBinding.editTextSearch.setText(result.get(0));
                    dataBinding.editTextSearch.setSelection(result.get(0).length());
                }
                break;
            }

        }
    }
    public void submitButtonClicked(View view) {
        String searchKey = dataBinding.editTextSearch.getText().toString();
        if(!searchKey.isEmpty() && searchKey.length() == 5){
            try {
                Integer.parseInt(searchKey);
                postalCode = searchKey;
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        if(!postalCode.isEmpty()) {
            new CurrentWeatherAsyncTask().execute("&zip=" + searchKey);
            new WeatherForecastAsyncTask().execute("&zip=" + searchKey);
            dataBinding.editTextSearch.setText("");
        }else{
            new CurrentWeatherAsyncTask().execute("&q=" + searchKey);
            new WeatherForecastAsyncTask().execute("&q=" + searchKey);
        }
    }


    public void buttonClicked(View view) {
        dataBinding.buttonLater.setBackgroundResource(R.drawable.button_default);
        dataBinding.buttonToday.setBackgroundResource(R.drawable.button_default);
        dataBinding.buttonTomorrow.setBackgroundResource(R.drawable.button_default);
        view.setBackgroundResource(R.drawable.button_selected);
        switch (view.getId()){
            case R.id.buttonToday:
                forecastAdapter.setList(today);
                break;
            case R.id.buttonTomorrow:
                forecastAdapter.setList(tomorrow);
                break;
            case R.id.buttonLater:
                forecastAdapter.setList(later);
                break;
        }

    }

    public void favButtonClicked(View view) {

        if(WeatherActivity.favoriteCities.contains(city)){
            WeatherActivity.dbAdapter.open();
            WeatherActivity.dbAdapter.deleteFavoriteCity(city);
            WeatherActivity.favoriteCities = WeatherActivity.dbAdapter.getFavoriteCities();
            WeatherActivity.dbAdapter.close();
            dataBinding.imageViewFavorite.setImageResource(android.R.drawable.star_big_off);
        }else{
            WeatherActivity.dbAdapter.open();
            WeatherActivity.dbAdapter.addFavoriteStation(city);
            WeatherActivity.favoriteCities = WeatherActivity.dbAdapter.getFavoriteCities();
            WeatherActivity.dbAdapter.close();
            dataBinding.imageViewFavorite.setImageResource(android.R.drawable.star_big_on);
        }

        adapter.clear();
        adapter.addAll(WeatherActivity.favoriteCities);
        adapter.notifyDataSetChanged();
    }

    public void speakNowClicked(View view) {
        promptSpeechInput();
    }


    private class CurrentWeatherAsyncTask extends AsyncTask<String, Void, String>{
        private WeatherResponse weatherResponse;
        @Override
        protected String doInBackground(String... strings) {
            String response = "";
            InputStream is = null;
            HttpURLConnection conn = null;
            URL url = null;
            String urlString = strings[0];
            urlString+=WeatherActivity.units == 0? "&units=imperial" : "&units=metric";

            try {
                url = new URL(WEATHER_BASE_URL + urlString.replaceAll(" ", "%20"));
                Log.d("CurrentWeatherAsyncTask", "The request is: " + url);

                conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(30000 /* milliseconds */);
                conn.setConnectTimeout(30000 /* milliseconds */);
                conn.setRequestMethod("GET");
                conn.setDoInput(true);
                conn.setRequestProperty("Content-Type", "application/json");
                conn.connect();
                int responseCode = conn.getResponseCode();
                Log.d("CurrentWeatherAsyncTask", "The response code is: " + responseCode);
                is = conn.getInputStream();
                // Convert the InputStream into a string
                java.util.Scanner s = new java.util.Scanner(is).useDelimiter("\\A");
                response = s.hasNext() ? s.next() : "";
                Log.d("CurrentWeatherAsyncTask", "The response is :" + response);
                weatherResponse = new Gson().fromJson(response, WeatherResponse.class);
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (is != null) {
                    try {
                        is.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if (conn != null) {
                    conn.disconnect();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            if(weatherResponse != null){
                city = weatherResponse.name;

                Bundle bundle = new Bundle();
                bundle.putString("City", city);
                mFirebaseAnalytics.logEvent(city, bundle);

                dataBinding.textViewCityName.setText(weatherResponse.name);
                dataBinding.textViewTemp.setText(weatherResponse.main.temp+ (WeatherActivity.units == 0 ? " \u2109" :" \u2103"));
                dataBinding.weatherCondition.setText(weatherResponse.weather.get(0).description);
                dataBinding.textViewHumidity.setText(weatherResponse.main.humidity+" %");
                dataBinding.textViewPressure.setText(weatherResponse.main.pressure+" hpa");
                dataBinding.textViewWind.setText(String.valueOf(weatherResponse.wind.speed+(WeatherActivity.units == 0 ? " m/h" :" m/s")));
                SimpleDateFormat localDateFormat = new SimpleDateFormat("hh:mm a");
                dataBinding.textViewSurise.setText(localDateFormat.format(new Date(weatherResponse.sys.sunrise*1000)));
                dataBinding.textViewSunset.setText(localDateFormat.format(new Date(weatherResponse.sys.sunset*1000)));
                dataBinding.textViewLastUpdate.setText(localDateFormat.format(new Date(weatherResponse.dt*1000)));
                String uri = IMAGE_BASE_URL+weatherResponse.weather.get(0).icon+".png";
                Log.i(TAG, "onPostExecute: IMAGE_BASE_URL :"+uri);
                Picasso.with(WeatherForecastActivity.this).load(Uri.parse(uri)).into(dataBinding.imageViewIcon);
                updateFavImage(city);
            }else{
                finish();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        adapter = new ArrayAdapter<String>
                (this,android.R.layout.simple_list_item_1, WeatherActivity.favoriteCities);
        dataBinding.editTextSearch.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

    public class WeatherForecastAsyncTask extends AsyncTask<String, Void, String> {
        WeatherForecastResponse weatherForecastResponse;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... strings) {

            String response = "";
            InputStream is = null;
            HttpURLConnection conn = null;
            URL url = null;
            String urlString = strings[0];
            urlString+=WeatherActivity.units == 0? "&units=imperial" : "&units=metric";
            try {
                url = new URL(FORECAST_BASE_URL + urlString.replaceAll(" ", "%20"));
                Log.d("WeatherForecast", "The request is: " + url);

                conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(30000 /* milliseconds */);
                conn.setConnectTimeout(30000 /* milliseconds */);
                conn.setRequestMethod("GET");
                conn.setDoInput(true);
                conn.setRequestProperty("Content-Type", "application/json");
                conn.connect();
                int responseCode = conn.getResponseCode();
                Log.d("WeatherForecast", "The response code is: " + responseCode);
                is = conn.getInputStream();
                // Convert the InputStream into a string
                java.util.Scanner s = new java.util.Scanner(is).useDelimiter("\\A");
                response = s.hasNext() ? s.next() : "";
                Log.d("WeatherForecast", "The response is :" + response);
                weatherForecastResponse = new Gson().fromJson(response, WeatherForecastResponse.class);
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (is != null) {
                    try {
                        is.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if (conn != null) {
                    conn.disconnect();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            postalCode = "";

            Calendar calendar = Calendar.getInstance();
            int todayDate = calendar.get(Calendar.DAY_OF_MONTH);
            calendar.add(Calendar.DAY_OF_MONTH, 1);
            int tomorrowDate = calendar.get(Calendar.DAY_OF_MONTH);
            today.clear();
            tomorrow.clear();
            later.clear();
            if(weatherForecastResponse == null){
                return;
            }
            for (Forecast forecast : weatherForecastResponse.list) {
                calendar.setTimeInMillis(forecast.dt*1000);
                int tempDate = calendar.get(Calendar.DAY_OF_MONTH);
                Log.i(TAG, "onPostExecute: tempDate :"+tempDate);
                if(tempDate == todayDate){
                    today.add(forecast);
                }else if(tempDate == tomorrowDate){
                    tomorrow.add(forecast);
                }else{
                    later.add(forecast);
                }

            }

            forecastAdapter = new ForecastAdapter(WeatherForecastActivity.this, today);
            dataBinding.forecastRecyclerView.setAdapter(forecastAdapter);
            dataBinding.buttonToday.setBackgroundResource(R.drawable.button_selected);
        }
    }
}
