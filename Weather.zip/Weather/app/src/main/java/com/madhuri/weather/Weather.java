package com.madhuri.weather;

/**
 * Created by reddve5 on 7/27/17.
 */

public class Weather {
    public int id = 0;
    public String main = "";
    public String description = "";
    public String icon = "";
}
